---
name: forge-ext-proposta-comercial
description: Gera propostas comerciais A4 da Maia Consultoria prontas para enviar ao cliente (PDF exportável via browser). ATIVE quando mencionar "proposta comercial", "orçamento para cliente", "proposta de consultoria", "proposta de projeto", "montar proposta", "escrever proposta", "gerar proposta", "proposta de serviço", "doc para fechar negócio", "proposta para o [cliente]", "quanto cobrar e como apresentar". Produz documento A4 multi-página com: capa, diagnóstico do problema, solução proposta, cronograma, investimento, termos, página de assinatura — com identidade Maia Consultoria.
version: 0.1.0
parent: forge-visual-canvas
depends: forge-ext-maia-brand
status: pronto-para-preencher
---

# Proposta Comercial — Maia Consultoria

Gera documento A4 multi-página exportável como PDF.
Usa `references/svg-document-engine.md` como engine de renderização.
Aplica identidade de `extensions/maia-brand/` sobre base Executive Swiss.

---

## Estrutura padrão (7 páginas)

| Pág | Seção | Conteúdo |
|---|---|---|
| 1 | **Capa** | Logo Maia, nome do cliente, título do projeto, data |
| 2 | **Contexto / Diagnóstico** | O problema que você vai resolver |
| 3 | **Solução Proposta** | O que você vai fazer, como e com quem |
| 4 | **Cronograma** | Timeline visual das etapas |
| 5 | **Investimento** | Tabela de valores, o que inclui, o que não inclui |
| 6 | **Termos** | Condições de pagamento, validade, metodologia |
| 7 | **Aprovação** | Campo de assinatura, data, dados das partes |

---

## Prompt para gerar a proposta

Cole este prompt no Claude e **substitua os campos `[...]`**:

```
FORGE: Gera uma proposta comercial A4 da Maia Consultoria para:

Cliente:       [NOME DO CLIENTE / EMPRESA]
Projeto:       [NOME DO PROJETO — ex: "Diagnóstico e Reestruturação Comercial"]
Data:          [DATA DE ENTREGA — ex: "Maio de 2025"]
Consultor:     João Maia — Maia Consultoria

CONTEXTO (problema do cliente):
[Descreva em 3-5 frases o problema que o cliente está enfrentando.
Ex: "A empresa tem 40% de taxa de churn nos primeiros 3 meses de contrato,
sem processo claro de onboarding e sem histórico de documentação de clientes."]

SOLUÇÃO PROPOSTA:
[Descreva em 3-5 frases o que você vai fazer.
Ex: "Levantamento do processo atual de onboarding, mapeamento de gaps,
definição de novo fluxo, treinamento da equipe e criação de playbook operacional."]

ENTREGAS:
- [Entrega 1 — ex: Mapeamento de processo atual]
- [Entrega 2 — ex: Playbook de onboarding]
- [Entrega 3 — ex: Treinamento de equipe (4h)]

CRONOGRAMA:
- Semana 1: [o que acontece]
- Semana 2: [o que acontece]
- Semana 3: [o que acontece]
- [adicionar ou remover semanas]

INVESTIMENTO:
Total: R$ [VALOR]
Forma de pagamento: [ex: 50% na assinatura, 50% na entrega]
Inclui: [o que está incluído]
Não inclui: [o que não está incluído — ex: viagens, ferramentas externas]

VALIDADE DA PROPOSTA: [ex: 15 dias]

Use estilo Executive Swiss + identidade Maia Consultoria.
Gere HTML com 7 páginas A4 (a4-page + SVG), exportável como PDF.
```

---

## Variações disponíveis

### Proposta curta (3 páginas)
Para projetos simples ou clientes já conhecidos:
- Pág 1: Capa
- Pág 2: Solução + Cronograma (consolidado)
- Pág 3: Investimento + Aprovação

No prompt, acrescente: `"Versão compacta — 3 páginas apenas: capa, solução+cronograma, investimento+assinatura."`

### Proposta de diagnóstico
Para quando ainda não sabe o escopo completo:
- Remove a seção "Solução Proposta"
- Adiciona seção "Metodologia de Diagnóstico" (como você vai entender o problema)
- Investimento separado em "Fase 1 — Diagnóstico" e "Fase 2 — Implementação (estimado)"

No prompt, acrescente: `"Formato diagnóstico: substitua 'solução' por 'metodologia de diagnóstico' e separe o investimento em Fase 1 e Fase 2."`

---

## Tom de linguagem (instrução pra Claude)

Proposta da Maia Consultoria usa:
- Linguagem direta, acessível, sem jargão
- Segunda pessoa (você / sua empresa)
- Frases curtas, parágrafos de 2-3 linhas
- Sem palavras como "sinergias", "ecossistema", "disruptivo", "paradigma"
- Objetividade acima de elegância — o cliente precisa entender em 5 minutos

---

## Checklist antes de enviar ao cliente

- [ ] Nome do cliente correto em todas as páginas
- [ ] Valor e condições de pagamento revisados
- [ ] Data de validade preenchida
- [ ] Dados de contato do rodapé corretos (extensions/maia-brand/SKILL.md)
- [ ] Exportado como PDF (Chrome → Print → Background graphics ON)
- [ ] Salvo com nome: `proposta-[cliente]-[data].pdf`
