---
name: forge-ext-diagnostico-presencial
description: Gera um painel de diagnóstico interativo para uso ao vivo durante reunião presencial com cliente. ATIVE quando mencionar "diagnóstico ao vivo", "usar na reunião", "tela para mostrar ao cliente", "preencher na frente do cliente", "diagnóstico presencial", "painel de diagnóstico", "levantamento ao vivo", "sessão de diagnóstico", "reunião de diagnóstico", "assessment presencial", "montar o diagnóstico com o cliente", "ferramenta para reunião". Produz artifact tela-cheia com campos que o João preenche em tempo real enquanto o cliente observa, e exporta PDF no final.
version: 0.1.0
parent: forge-visual-canvas
depends: forge-ext-maia-brand
status: pronto-para-usar
---

# Diagnóstico Presencial — Painel ao Vivo

Artifact de **uso durante a reunião com o cliente**.
João preenche os campos enquanto conversa — o cliente vê se montando na tela.
No final, exporta como PDF ou compartilha o link.

---

## O que entrega

- **Tela cheia** (sem distrações — sem sidebar, sem browser chrome visível)
- **Font grande** (legível a 1 metro de distância)
- **Inputs ao vivo** — João digita, cliente vê em tempo real
- **Seções do diagnóstico** (configuráveis no prompt)
- **Export PDF** ao final (via botão "Imprimir")
- **Identidade Maia Consultoria** (quando maia-brand estiver preenchida)

---

## Prompt para gerar o painel

Cole este prompt no Claude e **substitua os campos `[...]`**:

```
FORGE: Gera um artifact HTML tela-cheia para diagnóstico presencial ao vivo.

Cliente:    [NOME DO CLIENTE / EMPRESA — ou deixe em branco para preencher na hora]
Setor:      [SETOR — ex: "Varejo", "Serviços", "Saúde"]
Data:       [DATA DA REUNIÃO]

ÁREAS DE DIAGNÓSTICO (adapte para o seu caso):

Área 1: [NOME — ex: "Comercial"]
  Perguntas guia:
  - [Pergunta 1 — ex: "Qual o ticket médio atual?"]
  - [Pergunta 2 — ex: "Quantos clientes novos por mês?"]
  - [Pergunta 3 — ex: "Qual a principal fonte de leads?"]

Área 2: [NOME — ex: "Operacional"]
  Perguntas guia:
  - [Pergunta 1]
  - [Pergunta 2]
  - [Pergunta 3]

Área 3: [NOME — ex: "Financeiro"]
  Perguntas guia:
  - [Pergunta 1]
  - [Pergunta 2]
  - [Pergunta 3]

[Adicione quantas áreas quiser]

ESCALA DE MATURIDADE (para cada área):
Opções: [1 - Inicial] [2 - Em desenvolvimento] [3 - Estabelecido] [4 - Otimizado]

SEÇÃO FINAL: Prioridades identificadas (top 3 problemas)

Design: Enterprise Dashboard + identidade Maia Consultoria
Fonte grande (18px mínimo body, 24px títulos de área)
Cada área em card separado com score visual de maturidade
Botão "Exportar PDF" no rodapé
```

---

## Anatomia do painel gerado

```
┌─────────────────────────────────────────────────┐
│  MAIA CONSULTORIA                     [Cliente] │
│  Diagnóstico Empresarial           [Data] [Setor]│
├─────────────────────────────────────────────────┤
│                                                  │
│  [ÁREA 1: Comercial]              Maturidade: ●● │
│  ┌─────────────────────────────────────────────┐ │
│  │ Ticket médio: [input grande_____________]   │ │
│  │ Clientes/mês: [input grande_____________]   │ │
│  │ Principal canal: [input grande__________]   │ │
│  └─────────────────────────────────────────────┘ │
│                                                  │
│  [ÁREA 2: Operacional]            Maturidade: ●○ │
│  ┌─────────────────────────────────────────────┐ │
│  │ [campos da área 2]                          │ │
│  └─────────────────────────────────────────────┘ │
│                                                  │
│  [ÁREA 3: Financeiro]             Maturidade: ●●●│
│  ...                                             │
│                                                  │
├─────────────────────────────────────────────────┤
│  TOP 3 PRIORIDADES                               │
│  1. [input]  2. [input]  3. [input]              │
├─────────────────────────────────────────────────┤
│  [Observações / notas livres da reunião]         │
│  [textarea grande]                               │
├─────────────────────────────────────────────────┤
│  [Exportar PDF]      [Limpar]    Maia Consultoria│
└─────────────────────────────────────────────────┘
```

---

## Variações

### Modo "só radar" — para reunião muito curta (30min)
Gera só o radar visual de maturidade por área — sem campos de texto, só os scores.
Acrescente no prompt: `"Versão simplificada: só radar de maturidade, sem campos de texto. 5 áreas, scores 1-5, design visual big and bold."`

### Modo "entrevista estruturada" — para primeiro contato
Substitui o formato card/área por um roteiro de perguntas em sequência, uma por vez (estilo quiz).
Acrescente no prompt: `"Modo entrevista: uma pergunta por tela, botão Próximo, progress bar, respostas acumulam no resumo final."`

### Modo "com benchmark" — para clientes mais sofisticados
Cada área mostra a resposta do cliente vs. benchmark do setor (que João preenche antes da reunião).
Acrescente no prompt: `"Adicionar coluna de benchmark do setor [preencha com números] ao lado de cada resposta do cliente."`

---

## Dicas de uso presencial

**Antes da reunião:**
1. Abra o artifact no notebook em tela cheia (F11)
2. Verifique que o nome do cliente e data estão pré-preenchidos
3. Conecte ao projetor / TV

**Durante a reunião:**
- Leia as perguntas guia em voz alta, responda nos campos
- O cliente vê você organizando o pensamento dele
- Use os scores de maturidade como âncora de conversa ("você está no nível 2, o padrão do setor é 3")

**Ao final:**
- Clique "Exportar PDF" — entrega na hora
- Ou envie o link do artifact por WhatsApp

**Efeito no cliente:** ver o diagnóstico se montando em tempo real cria percepção de valor muito maior do que chegar com um relatório pronto.
