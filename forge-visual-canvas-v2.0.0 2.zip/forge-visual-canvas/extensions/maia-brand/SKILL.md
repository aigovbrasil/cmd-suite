---
name: forge-ext-maia-brand
description: Identidade visual da Maia Consultoria aplicada em todos os artifacts. ATIVE quando o pedido mencionar "Maia Consultoria", "minha marca", "identidade da consultoria", "branding pessoal", "com a minha cara", "com o meu logo", "cor da minha empresa", "documento com minha marca", ou qualquer artifact destinado a ser apresentado ao cliente final com identidade própria do João. NÃO ATIVE para artifacts de referência interna ou experimentos sem identidade de marca.
version: 0.1.0
parent: forge-visual-canvas
status: pronto-para-preencher
---

# Maia Brand — Identidade Visual da Maia Consultoria

Extensão de brand da Maia Consultoria.
Herda os tokens base do FORGE e os sobrescreve com a identidade do João.

**⚠️ PREENCHA OS CAMPOS MARCADOS COM [DEFINIR] ANTES DE USAR**

---

## Tokens da Maia Consultoria

```css
/* ─────────────────────────────────────────
   PREENCHA: substitua os valores [DEFINIR]
   pelas cores reais da sua marca.
   Se ainda não tiver, use os padrões abaixo
   como ponto de partida.
   ───────────────────────────────────────── */

:root {
  /* Cor principal da marca */
  --maia-primary:       [DEFINIR];  /* ex: #1a3a5c (azul escuro confiança) */

  /* Cor de destaque (CTAs, highlights) */
  --maia-accent:        [DEFINIR];  /* ex: #d97757 (manter o FORGE orange) */

  /* Cor secundária (info, links) */
  --maia-secondary:     [DEFINIR];  /* ex: #3a7ca5 */

  /* Cor de fundo leve */
  --maia-bg-light:      [DEFINIR];  /* ex: #f8f9fc */

  /* Texto principal */
  --maia-text:          [DEFINIR];  /* ex: #141413 */

  /* ─────────────────────────────────────── */
  /* TIPOGRAFIA (escolha uma opção):         */
  /*   A) manter Poppins/Lora (default)      */
  /*   B) trocar por fontes da sua marca     */
  /* ─────────────────────────────────────── */
  --maia-font-heading:  'Poppins', Arial, sans-serif;   /* [DEFINIR se quiser trocar] */
  --maia-font-body:     'Lora', Georgia, serif;          /* [DEFINIR se quiser trocar] */
}
```

---

## Identidade da marca (preencha)

```
Nome completo:    Maia Consultoria
Nome curto:       Maia

Slogan/tagline:   [DEFINIR — ex: "Consultoria que fala a sua língua"]

Endereço:         [DEFINIR]
Telefone/WA:      [DEFINIR]
Email:            [DEFINIR]
Site:             [DEFINIR]

LinkedIn:         [DEFINIR]
Instagram:        [DEFINIR]

Nome do consultor: João Maia
Título:            [DEFINIR — ex: "Consultor de Gestão"]
```

---

## Logo (instrução para Claude)

```
Logo disponível como arquivo?   [SIM / NÃO]
Caminho do arquivo:             [DEFINIR — ex: assets/logo-maia.svg]
Versão dark (fundo escuro):     [SIM / NÃO — caminho: assets/logo-maia-dark.svg]
Versão só ícone (favicon):      [SIM / NÃO — caminho: assets/logo-maia-icon.svg]

Se não houver logo ainda: usar monograma "M" em --maia-primary com
font-family --maia-font-heading, weight 800, sobre fundo --maia-primary.
```

---

## Padrão de rodapé em documentos com marca Maia

Todo artifact com identidade Maia Consultoria deve incluir este rodapé:

```
MAIA CONSULTORIA  ·  [telefone]  ·  [email]  ·  [site]
```

Em SVG (documentos A4):
```svg
<line x1="60" y1="1023" x2="734" y2="1023" stroke="var(--maia-primary)" stroke-width="1" opacity="0.3"/>
<text x="60" y="1055" font-family="'JetBrains Mono', monospace" fill="var(--maia-primary)"
      font-size="11" opacity="0.6">MAIA CONSULTORIA  ·  [DEFINIR telefone]  ·  [DEFINIR email]</text>
<text x="734" y="1055" font-family="'JetBrains Mono', monospace" fill="var(--maia-primary)"
      font-size="11" opacity="0.6" text-anchor="end">PG. {N}</text>
```

Em HTML:
```html
<footer style="
  border-top: 1px solid var(--maia-primary, #1a3a5c);
  padding: 12px 0 0;
  font-family: 'JetBrains Mono', monospace;
  font-size: 11px;
  color: var(--maia-primary, #1a3a5c);
  opacity: 0.7;
  display: flex;
  justify-content: space-between;
">
  <span>MAIA CONSULTORIA  ·  [DEFINIR telefone]  ·  [DEFINIR email]</span>
  <span>[DEFINIR site]</span>
</footer>
```

---

## Como aplicar em qualquer artifact

Quando `forge-ext-maia-brand` ativar junto com `forge-visual-canvas`:

1. Carregar tokens CSS desta extensão **sobre** os tokens base FORGE
2. Substituir rodapé genérico pelo rodapé Maia acima
3. Colocar logo no canto superior esquerdo de documentos A4 (x=60, y=30 em SVG)
4. Usar `--maia-primary` como cor do sidebar em documentos (ao invés de `#1a365d` genérico)

**Merge de tokens (padrão):**
```js
const MAIA_TOKENS = {
  '--accent':       'var(--maia-accent)',
  '--text-primary': 'var(--maia-text)',
  '--bg':           'var(--maia-bg-light)',
};
// aplicar após os tokens da linguagem visual escolhida
Object.entries(MAIA_TOKENS).forEach(([k, v]) =>
  document.documentElement.style.setProperty(k, v));
```

---

## Checklist antes de usar em cliente final

- [ ] Todas os campos `[DEFINIR]` preenchidos
- [ ] Logo disponível (ou monograma configurado)
- [ ] Cores testadas em dark mode
- [ ] Rodapé com contato real
- [ ] Slogan/tagline definida
