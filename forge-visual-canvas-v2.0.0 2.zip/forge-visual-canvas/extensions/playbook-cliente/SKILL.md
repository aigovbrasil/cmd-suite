---
name: forge-ext-playbook-cliente
description: Gera um playbook operacional entregue ao cliente no fechamento do projeto de consultoria. ATIVE quando mencionar "playbook do cliente", "manual do cliente", "documento de encerramento", "entregável final", "fechar o projeto", "deixar com o cliente", "o que fica para o cliente", "guia de operação", "como operar depois de mim", "continuidade do projeto", "pós-consultoria", "playbook operacional", "SOP do cliente", "rotina do cliente". Produz documento A4 multi-página com: visão geral do que foi feito, processos documentados (SOPs), métricas de acompanhamento, quando retornar para consultoria.
version: 0.1.0
parent: forge-visual-canvas
depends: forge-ext-maia-brand
status: pronto-para-preencher
---

# Playbook do Cliente — Entregável de Fechamento

Documento deixado com o cliente no encerramento do projeto.
Marca o fim do engajamento e ancora o cliente para a próxima rodada.

---

## Estrutura padrão (5-8 páginas)

| Pág | Seção | Conteúdo |
|---|---|---|
| 1 | **Capa** | "Playbook [Nome do Projeto] — [Nome do Cliente]" |
| 2 | **O que foi feito** | Resumo executivo do projeto, entregas realizadas, resultados |
| 3–4 | **SOPs — Processos documentados** | Passo a passo dos processos implantados |
| 5 | **Métricas para acompanhar** | KPIs, o que monitorar e com qual frequência |
| 6 | **Cronograma de revisão** | Quando revisar, o que pode mudar, quando buscar suporte |
| 7 | **Quando me chamar de volta** | Sinais de que precisa de nova rodada de consultoria |
| 8 | **Contato** | Dados da Maia Consultoria + proposta de continuidade |

---

## Prompt para gerar o playbook

Cole este prompt no Claude e **substitua os campos `[...]`**:

```
FORGE: Gera um playbook operacional A4 da Maia Consultoria para encerramento de projeto.

Cliente:          [NOME DO CLIENTE / EMPRESA]
Projeto:          [NOME DO PROJETO — ex: "Reestruturação do Processo de Vendas"]
Período:          [DURAÇÃO — ex: "Março–Abril 2025"]
Consultor:        João Maia — Maia Consultoria

O QUE FOI FEITO (resultados do projeto):
[Descreva 3-5 conquistas mensuráveis.
Ex: "Redução de 30% no tempo de onboarding. Criação de 3 SOPs documentados.
Implantação de CRM com 100% da equipe treinada."]

PROCESSOS DOCUMENTADOS (SOPs):

SOP 1: [NOME — ex: "Onboarding de Novo Cliente"]
Responsável: [quem faz]
Frequência: [quando faz]
Passo a passo:
1. [passo]
2. [passo]
3. [passo]
[adicionar passos]

SOP 2: [NOME]
[mesma estrutura]

[adicionar quantos SOPs precisar]

MÉTRICAS PARA ACOMPANHAR:
- [Métrica 1]: [o que é] / [como medir] / [frequência] / [meta]
- [Métrica 2]: [o que é] / [como medir] / [frequência] / [meta]
- [Métrica 3]: [o que é] / [como medir] / [frequência] / [meta]

CRONOGRAMA DE REVISÃO SUGERIDO:
- 30 dias: [o que revisar]
- 90 dias: [o que revisar]
- 6 meses: [o que revisar]

SINAIS DE ALERTA (quando me chamar de volta):
- [Sinal 1 — ex: "Taxa de churn subir acima de 15%"]
- [Sinal 2]
- [Sinal 3]

PROPOSTA DE CONTINUIDADE (opcional):
[Descreva a próxima fase, se houver — ou deixe em branco]

Design: Editorial Premium + identidade Maia Consultoria
Páginas A4 exportáveis como PDF
Tom: direto, prático, escrito para o operador — não para o CEO
```

---

## Tom do playbook

O playbook é escrito **para quem vai executar**, não para o gestor:
- Sem jargão de consultoria
- Imperativos diretos ("Acesse o CRM toda segunda-feira")
- Prints / screenshots quando disponíveis (o Claude pode criar mockups)
- Listas de checklist, não parágrafos longos
- "Quando isso acontecer, faça isso" — lógica condicional clara

---

## Variação: playbook de 1 página (resumo executivo)

Para projetos curtos ou como sumário do documento completo.
Formato: A4 único, duas colunas — "O que mudou" + "Como manter".

No prompt, acrescente: `"Versão 1 página: duas colunas, 'O que mudou' à esquerda, 'Como manter' à direita. Design compacto, font menor, sem SOPs detalhados."`

---

## Estratégia de continuidade

A última página do playbook sempre inclui um convite suave para retorno:

```
"Projetos de consultoria não terminam — evoluem.
Se algum dos sinais de alerta acima aparecer,
ou se você quiser avançar para a próxima fase,
fale comigo:

João Maia · Maia Consultoria
[contato]

Próxima revisão sugerida: [data]"
```

Este trecho é gerado automaticamente quando `forge-ext-maia-brand` está preenchido.
